---
title: New GNAT Project
---


This is the first step in creating a [GNAT Project](GNAT_Project). 


