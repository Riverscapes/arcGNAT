---
title: Load Network
---


This tool loads a polyline network feature class into the [GNAT Project](GNAT_Project).