### GNAT

The **Geomorphic Network and Analysis Toolbox (GNAT)** is an ArcGIS Python toolbox that has been 
developed by [South Fork Research, Inc.](http://www.southforkresearch.org) to assist with data 
processing and analysis of geospatial stream network data.

Detailed download and installation instructions, as well as help files for each of the GNAT tools 
is available at [gnat.riverscapes.xyz](http://gnat.riverscapes.xyz).